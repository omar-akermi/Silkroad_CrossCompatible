﻿namespace SOE
{
    public class QuestData
    {
        public string Title;
        public string Task;
        public int Reward;
        public string ProductID;
        public uint AmountRequired;
        public string TargetObjectName;
    }
}