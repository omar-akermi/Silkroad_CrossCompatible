﻿namespace S1API.NPCs
{
    public class NPCManager
    {
        
    }
}