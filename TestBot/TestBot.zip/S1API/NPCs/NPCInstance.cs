﻿#if (IL2CPP)
using S1NPCs = Il2CppScheduleOne.NPCs;
#elif (MONO)
using S1NPCs = ScheduleOne.NPCs;
#endif

namespace S1API.NPCs
{
    public class NPCInstance
    {
        
    }
}