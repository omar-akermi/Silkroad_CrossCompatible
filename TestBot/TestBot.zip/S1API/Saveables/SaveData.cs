﻿namespace S1API.Saveables
{
    /// <summary>
    /// Generic data applied to all save data.
    /// </summary>
    public abstract class SaveData
    {
        public string DataType = string.Empty;
    }
}