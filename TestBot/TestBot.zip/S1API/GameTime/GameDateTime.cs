﻿// TODO: Implement GameDateTime wrapper
// #if (IL2CPP)
// using S1GameTime = Il2CppScheduleOne.GameTime;
// #elif (MONO)
// using S1GameTime = ScheduleOne.GameTime;
// #endif
//
// namespace S1API.API.GameTime
// {
//     struct GameDateTime
//     {
//         public int elapsedDays;
//         public int time;
//         
//         public GameDateTime(S1GameTime.GameDateTime gameDateTime)
//         {
//             
//         }
//         
//         public void Ad
//     }
// }