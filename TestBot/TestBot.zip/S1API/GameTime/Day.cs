﻿namespace S1API.GameTime
{
    /// <summary>
    /// Represents all days available in the week.
    /// </summary>
    public enum Day
    {
        Monday,
        Tuesday,
        Wednesday,
        Thursday,
        Friday,
        Saturday,
        Sunday
    }
}