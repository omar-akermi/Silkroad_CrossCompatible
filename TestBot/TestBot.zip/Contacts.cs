﻿using S1API.Quests;
using SilkRoad.Quests;

namespace SilkRoad.Quests
{
    public static class Contacts
    {
        public static BlackmarketBuyer Buyer { get; internal set; }
    }
}
